import express from "express";
import { createServer as createViteServer } from "vite";
import multer from "multer";
import path from "path";
import fs from "fs";
import { fileURLToPath } from "url";
import Database from "better-sqlite3";
import crypto from "crypto";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const db = new Database("music.db");

  // Initialize database
  db.exec(`
    CREATE TABLE IF NOT EXISTS beats (
      id TEXT PRIMARY KEY,
      title TEXT NOT NULL,
      genre TEXT NOT NULL,
      duration TEXT NOT NULL,
      bpm INTEGER NOT NULL,
      price REAL NOT NULL,
      sold INTEGER DEFAULT 0,
      audioUrl TEXT NOT NULL,
      createdAt INTEGER DEFAULT (strftime('%s', 'now'))
    )
  `);

  // Ensure createdAt column exists for older databases
  try {
    db.exec("ALTER TABLE beats ADD COLUMN createdAt INTEGER DEFAULT (strftime('%s', 'now'))");
  } catch (e) {
    // Column already exists
  }

  // Seed database if empty
  const count = db.prepare("SELECT COUNT(*) as count FROM beats").get() as any;
  if (count.count === 0) {
    const INITIAL_BEATS = [
      {
        id: '1',
        title: 'Flow Imer Vol 1',
        genre: 'Reggaeton',
        duration: '3:05',
        bpm: 95,
        price: 60,
        audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3'
      },
      {
        id: '2',
        title: 'Dark Knight',
        genre: 'Trap',
        duration: '2:45',
        bpm: 140,
        price: 45,
        audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3'
      },
      {
        id: '3',
        title: 'Midnight Vibes',
        genre: 'Trap',
        duration: '02:45',
        bpm: 140,
        price: 65,
        audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3'
      }
    ];

    const insert = db.prepare(`
      INSERT INTO beats (id, title, genre, duration, bpm, price, audioUrl, createdAt)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    const now = Math.floor(Date.now() / 1000);
    INITIAL_BEATS.forEach((beat, index) => {
      // Offset timestamps slightly so they have a deterministic order
      insert.run(beat.id, beat.title, beat.genre, beat.duration, beat.bpm, beat.price, beat.audioUrl, now - (INITIAL_BEATS.length - index));
    });
    console.log("Database seeded with initial beats");
  }

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Ensure uploads directory exists
  const uploadDir = path.join(__dirname, "public", "uploads");
  if (!fs.existsSync(uploadDir)) {
    fs.mkdirSync(uploadDir, { recursive: true });
  }

  // Multer configuration
  const storage = multer.diskStorage({
    destination: (req, file, cb) => {
      cb(null, uploadDir);
    },
    filename: (req, file, cb) => {
      const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9);
      cb(null, uniqueSuffix + path.extname(file.originalname));
    },
  });

  const upload = multer({ 
    storage,
    limits: { fileSize: 100 * 1024 * 1024 }, // Increased to 100MB
    fileFilter: (req, file, cb) => {
      const allowedTypes = [".wav", ".mp3", ".m4a", ".ogg", ".flac"];
      const isAllowed = allowedTypes.some(ext => file.originalname.toLowerCase().endsWith(ext));
      if (isAllowed) {
        cb(null, true);
      } else {
        cb(new Error("Solo se permiten archivos de audio (.wav, .mp3, .m4a, .ogg, .flac)"));
      }
    }
  });

  app.use(express.json({ limit: '100mb' }));
  app.use(express.urlencoded({ limit: '100mb', extended: true }));

  // Serve uploads directory explicitly
  app.use("/uploads", express.static(path.join(__dirname, "public", "uploads")));

  // API Route to get all beats
  app.get("/api/beats", (req, res) => {
    try {
      const beats = db.prepare("SELECT * FROM beats ORDER BY createdAt DESC, id DESC").all();
      res.json(beats.map((b: any) => ({ ...b, sold: !!b.sold })));
    } catch (error) {
      console.error("Error fetching beats:", error);
      res.status(500).json({ error: "Error al obtener el catálogo" });
    }
  });

  // API Route for file upload and beat creation
  app.post("/api/upload", (req, res, next) => {
    console.log("--- Upload Request Started ---");
    console.log("Headers:", req.headers['content-type']);
    next();
  }, upload.single("audio"), (req, res) => {
    console.log("Multer finished processing");
    console.log("File:", req.file ? {
      originalname: req.file.originalname,
      filename: req.file.filename,
      size: req.file.size,
      mimetype: req.file.mimetype
    } : "No file");
    console.log("Body:", req.body);

    if (!req.file) {
      return res.status(400).json({ error: "No se recibió ningún archivo de audio válido" });
    }
    
    const { title, genre, price, duration, bpm } = req.body;
    const audioUrl = `/uploads/${req.file.filename}`;
    const id = crypto.randomUUID();
    
    const parsedBpm = parseInt(bpm) || 0;
    const parsedPrice = parseFloat(price) || 0;
    const createdAt = Math.floor(Date.now() / 1000);
    
    try {
      const stmt = db.prepare(`
        INSERT INTO beats (id, title, genre, duration, bpm, price, audioUrl, createdAt)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      `);
      stmt.run(id, title, genre, duration, parsedBpm, parsedPrice, audioUrl, createdAt);
      
      console.log("Beat saved to DB:", id);

      res.json({ 
        id,
        title: title || "Sin título",
        genre: genre || "Varios",
        duration: duration || "0:00",
        bpm: parsedBpm,
        price: parsedPrice,
        audioUrl,
        sold: false,
        createdAt
      });
    } catch (error) {
      console.error("Database error during upload:", error);
      res.status(500).json({ error: "Error al guardar la pista en la base de datos" });
    }
  }, (err: any, req: any, res: any, next: any) => {
    console.error("Multer/Upload Middleware Error:", err);
      if (err instanceof multer.MulterError) {
        if (err.code === 'LIMIT_FILE_SIZE') {
          return res.status(413).json({ error: "El archivo excede el límite del servidor (100MB). Por favor usa FLAC o MP3 si el archivo es muy grande." });
        }
      return res.status(400).json({ error: `Error de carga: ${err.message}` });
    }
    res.status(400).json({ error: err.message || "Error desconocido en la subida" });
  });

  // Serve static files from public
  app.use(express.static(path.join(__dirname, "public")));

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    // Production: serve from dist
    app.use(express.static(path.join(__dirname, "dist")));
    app.get("*", (req, res) => {
      res.sendFile(path.join(__dirname, "dist", "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });

  // Global error handler
  app.use((err: any, req: any, res: any, next: any) => {
    console.error("Global error handler:", err);
    if (!res.headersSent) {
      res.status(500).json({ error: err.message || "Error interno del servidor" });
    }
  });
}

startServer();
