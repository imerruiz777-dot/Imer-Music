/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useRef, FormEvent } from 'react';
import { 
  Youtube, 
  Instagram, 
  Twitter, 
  Music, 
  Check, 
  Info, 
  MessageSquare, 
  Send, 
  X, 
  Download, 
  Cpu, 
  Globe, 
  Mic,
  ChevronRight,
  ExternalLink,
  Search,
  Play,
  Pause,
  Lock,
  Plus,
  Filter
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

// --- Types ---
interface Beat {
  id: string;
  title: string;
  genre: string;
  duration: string;
  bpm: number;
  price: number;
  sold: boolean;
  audioUrl?: string;
}

// --- Genres ---
const GENRES = [
  'Todos', 
  'Reggaeton', 
  'Trap', 
  'Rap', 
  'Dancehall', 
  'Dembow',
  'R&B',
  'Pop',
  'Afrobeat',
  'Drill',
  'Lo-Fi',
  'House',
  'Techno',
  'Rock',
  'Salsa',
  'Bachata',
  'Merengue',
  'Jazz',
  'Blues',
  'Funk',
  'Soul',
  'Country',
  'EDM',
  'Dubstep',
  'Phonk'
];

const Speaker = ({ side, isPlaying }: { side: 'left' | 'right', isPlaying: boolean }) => {
  return (
    <motion.div
      animate={isPlaying ? {
        scale: [1, 1.02, 1],
        x: side === 'left' ? [0, 1, 0] : [0, -1, 0],
        y: [0, -1, 0]
      } : {}}
      transition={{
        duration: 0.1,
        repeat: Infinity,
        ease: "linear"
      }}
      className={`fixed top-24 ${side === 'left' ? 'left-4' : 'right-4'} z-40 hidden xl:block w-48`}
    >
      <div className="card-glass p-6 rounded-[2rem] border-2 border-[#00f2ff]/30 flex flex-col items-center gap-6 shadow-[0_0_40px_rgba(0,242,255,0.15)] bg-black/80">
        {/* Brand Label */}
        <div className="flex flex-col items-center gap-1">
          <div className="text-[7px] font-black tracking-[0.4em] text-[#00f2ff] uppercase opacity-80">Studio Monitor</div>
          <div className="text-[10px] font-black tracking-[0.2em] text-white uppercase">Imer Music</div>
        </div>
        
        {/* Tweeter (High Frequency) */}
        <div className="w-14 h-14 rounded-full bg-zinc-900 border border-[#00f2ff]/40 flex items-center justify-center relative overflow-hidden group">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(0,242,255,0.15),transparent_70%)]" />
          <div className="w-6 h-6 rounded-full bg-zinc-800 border border-white/10 flex items-center justify-center">
            <div className={`w-2 h-2 rounded-full transition-all duration-300 ${isPlaying ? 'bg-[#00f2ff] shadow-[0_0_10px_#00f2ff]' : 'bg-zinc-600'}`} />
          </div>
          {/* Decorative rings */}
          <div className="absolute inset-0 border border-[#00f2ff]/5 rounded-full scale-75" />
        </div>

        {/* Woofer (Low Frequency) */}
        <div className="relative">
          <motion.div 
            animate={isPlaying ? { 
              scale: [1, 1.08, 1],
              boxShadow: ["0 0 0px rgba(0,242,255,0)", "0 0 20px rgba(0,242,255,0.2)", "0 0 0px rgba(0,242,255,0)"]
            } : {}}
            transition={{ duration: 0.15, repeat: Infinity }}
            className="w-32 h-32 rounded-full bg-zinc-900 border-2 border-[#00f2ff]/20 flex items-center justify-center relative shadow-inner overflow-hidden"
          >
            {/* Carbon fiber texture simulation */}
            <div className="absolute inset-0 opacity-10 bg-[repeating-linear-gradient(45deg,transparent,transparent_2px,#00f2ff_2px,#00f2ff_4px)]" />
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(0,242,255,0.05),transparent_80%)]" />
            
            <div className="w-24 h-24 rounded-full border border-[#00f2ff]/10 flex items-center justify-center">
              <div className="w-14 h-14 rounded-full bg-linear-to-br from-zinc-800 to-black border border-white/5 shadow-2xl" />
            </div>
          </motion.div>
          
          {/* Vibration waves */}
          {isPlaying && (
            <>
              <motion.div 
                initial={{ scale: 1, opacity: 0.5 }}
                animate={{ scale: 1.5, opacity: 0 }}
                transition={{ duration: 0.5, repeat: Infinity }}
                className="absolute inset-0 border border-[#00f2ff]/20 rounded-full"
              />
              <motion.div 
                initial={{ scale: 1, opacity: 0.3 }}
                animate={{ scale: 1.8, opacity: 0 }}
                transition={{ duration: 0.5, repeat: Infinity, delay: 0.2 }}
                className="absolute inset-0 border border-[#00f2ff]/10 rounded-full"
              />
            </>
          )}
        </div>

        {/* Control Panel / Lights */}
        <div className="flex items-center gap-3 bg-black/40 px-3 py-1.5 rounded-full border border-white/5">
          <div className={`w-1.5 h-1.5 rounded-full transition-all duration-300 ${isPlaying ? 'bg-[#00f2ff] shadow-[0_0_8px_#00f2ff]' : 'bg-zinc-800'}`} />
          <div className="w-6 h-0.5 bg-zinc-800 rounded-full overflow-hidden">
            <motion.div 
              animate={{ x: isPlaying ? [-24, 24] : -24 }}
              transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
              className="w-full h-full bg-[#00f2ff]/50"
            />
          </div>
          <div className="text-[6px] font-bold text-zinc-500 tracking-tighter">ACTIVE</div>
        </div>
      </div>
      
      {/* Speaker Stand Shadow */}
      <div className="mt-4 h-1 w-3/4 mx-auto bg-[#00f2ff]/5 blur-md rounded-full" />
    </motion.div>
  );
};

export default function App() {
  const [beats, setBeats] = useState<Beat[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedGenre, setSelectedGenre] = useState('Todos');
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isAdminOpen, setIsAdminOpen] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [downloadCode, setDownloadCode] = useState('');
  const [playingId, setPlayingId] = useState<string | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  
  const [chatMessages, setChatMessages] = useState<{ text: string; isUser: boolean }[]>([
    { text: '¡Hola! Soy el asistente de Imer Music. ¿Buscas un beat o quieres unirte al sello?', isUser: false }
  ]);
  const [chatInput, setChatInput] = useState('');
  const chatBodyRef = useRef<HTMLDivElement>(null);

  // Filtered Beats
  const filteredBeats = beats.filter(beat => {
    const matchesSearch = beat.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                         beat.genre.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesGenre = selectedGenre === 'Todos' || beat.genre === selectedGenre;
    return matchesSearch && matchesGenre;
  });

  useEffect(() => {
    const fetchBeats = async () => {
      try {
        const response = await fetch('/api/beats');
        if (response.ok) {
          const data = await response.json();
          setBeats(data);
        }
      } catch (error) {
        console.error("Failed to fetch beats:", error);
      }
    };
    fetchBeats();
  }, []);

  // Audio Logic
  const togglePlay = (beat: Beat) => {
    if (playingId === beat.id) {
      audioRef.current?.pause();
      setPlayingId(null);
    } else {
      if (audioRef.current) {
        audioRef.current.src = beat.audioUrl || '';
        audioRef.current.play();
      }
      setPlayingId(beat.id);
    }
  };

  useEffect(() => {
    audioRef.current = new Audio();
    audioRef.current.onended = () => setPlayingId(null);
    return () => {
      audioRef.current?.pause();
      audioRef.current = null;
    };
  }, []);

  // Admin Logic
  const handleAddBeat = async (e: FormEvent) => {
    e.preventDefault();
    setIsUploading(true);
    
    try {
      const form = e.target as HTMLFormElement;
      const formData = new FormData(form);
      const audioFile = formData.get('audio') as File;

      if (!audioFile || audioFile.size === 0) {
        alert("Por favor selecciona un archivo de audio");
        setIsUploading(false);
        return;
      }

      const allowedExtensions = ['.wav', '.mp3', '.m4a', '.ogg', '.flac'];
      const fileName = audioFile.name.toLowerCase();
      const isAllowed = allowedExtensions.some(ext => fileName.endsWith(ext));

      if (!isAllowed) {
        alert("Solo se permiten archivos de audio (.wav, .mp3, .m4a, .ogg, .flac)");
        setIsUploading(false);
        return;
      }

      if (audioFile.size > 100 * 1024 * 1024) {
        alert("¡Error 413! El archivo es demasiado grande (Límite: 100MB).\n\nSi tu archivo es un WAV extremadamente pesado, por favor conviértelo a FLAC (misma calidad, mucho menos peso) o MP3 de alta calidad.");
        setIsUploading(false);
        return;
      }

      // Upload file to server
      const uploadResponse = await fetch('/api/upload', {
        method: 'POST',
        body: formData,
      });

      if (!uploadResponse.ok) {
        if (uploadResponse.status === 413) {
          throw new Error("Error 413: El archivo es demasiado grande para la red. Si tu archivo pesa cerca de 35MB y ves este error, es un límite físico de la infraestructura de Google Cloud que no puedo cambiar. Por favor, usa el formato FLAC (misma calidad, mucho menos peso).");
        }
        
        const contentType = uploadResponse.headers.get("content-type");
        if (contentType && contentType.includes("application/json")) {
          const errorData = await uploadResponse.json();
          throw new Error(errorData.error || 'Error al subir el archivo');
        } else {
          const textError = await uploadResponse.text();
          console.error("Server returned non-JSON error:", textError);
          // If it's a large HTML response, don't show the whole thing in the alert
          const shortError = textError.length > 100 ? textError.substring(0, 100) + "..." : textError;
          throw new Error(`Error del servidor (${uploadResponse.status}): El servidor no respondió con JSON. Respuesta: ${shortError}`);
        }
      }

      const contentType = uploadResponse.headers.get("content-type");
      if (contentType && contentType.includes("application/json")) {
        const beatData = await uploadResponse.json();
        
        // Ensure beatData has the correct structure
        const newBeat: Beat = {
          ...beatData,
          sold: !!beatData.sold
        };
        
        setBeats(prev => [newBeat, ...prev]);
        setSelectedGenre('Todos');
        setSearchQuery('');
        
        // Generate the code for the new beat
        const beatTitleSlug = beatData.title.toUpperCase().replace(/\s+/g, '-');
        const beatRef = beatData.id.substring(0, 4).toUpperCase();
        const generatedCode = `${beatTitleSlug}-${beatRef}`;
        
        // Show a more prominent success state
        alert(`¡PISTA PUBLICADA!\n\nCódigo: ${generatedCode}\n\nSe ha añadido al catálogo. Ahora puedes enviarlo por WhatsApp desde la lista de gestión.`);
        
        // Automatically trigger WhatsApp if they want
        const message = `🎹 *NUEVO CÓDIGO DE DESCARGA - IMER MUSIC* 🎹%0A%0A` +
                        `*Pista:* ${beatData.title}%0A` +
                        `*Código:* ${generatedCode}%0A%0A` +
                        `Guarda este código para entregarlo al cliente tras el pago.`;
        
        window.open(`https://wa.me/584244737109?text=${message}`, '_blank');

        form.reset();
      } else {
        throw new Error("El servidor no devolvió una respuesta JSON válida tras la subida.");
      }
    } catch (error: any) {
      console.error('Upload error:', error);
      alert(`Error: ${error.message}`);
    } finally {
      setIsUploading(false);
    }
  };

  // Scroll chat to bottom
  useEffect(() => {
    if (chatBodyRef.current) {
      chatBodyRef.current.scrollTop = chatBodyRef.current.scrollHeight;
    }
  }, [chatMessages]);

  const handleSendMessage = () => {
    if (!chatInput.trim()) return;
    
    setChatMessages(prev => [...prev, { text: chatInput, isUser: true }]);
    const currentInput = chatInput;
    setChatInput('');

    setTimeout(() => {
      setChatMessages(prev => [...prev, { 
        text: 'Excelente, Imer revisará tu mensaje pronto. Para una respuesta inmediata, haz clic en el botón de WhatsApp del menú.', 
        isUser: false 
      }]);
    }, 1000);
  };

  const handleDownload = () => {
    const code = downloadCode.trim().toUpperCase();
    if (!code) return;

    // Find a beat that matches the code pattern: TITLE-REF
    // Where REF is the first 4 chars of the beat ID
    const matchedBeat = beats.find(beat => {
      const beatTitleSlug = beat.title.toUpperCase().replace(/\s+/g, '-');
      const beatRef = beat.id.substring(0, 4).toUpperCase();
      const expectedCode = `${beatTitleSlug}-${beatRef}`;
      return code === expectedCode;
    });

    if (matchedBeat) {
      if (matchedBeat.audioUrl) {
        alert(`✅ Código validado: "${matchedBeat.title}". Iniciando descarga...`);
        
        // Create a temporary link to trigger download
        const link = document.createElement('a');
        link.href = matchedBeat.audioUrl;
        link.setAttribute('download', `${matchedBeat.title}.wav`);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      } else {
        alert("❌ Error: El archivo de audio no está disponible.");
      }
    } else {
      alert("❌ Código inválido o expirado. Asegúrate de escribirlo exactamente como te lo proporcionó Imer.");
    }
  };

  const handleMembershipSubmit = (e: FormEvent) => {
    e.preventDefault();
    const formData = new FormData(e.target as HTMLFormElement);
    const name = formData.get('art-name');
    const genre = formData.get('art-genre');
    const ig = formData.get('art-ig');

    const message = `🔥 *NUEVA SOLICITUD DE SELLO IMER MUSIC* 🔥%0A%0A` +
                    `*Artista:* ${name}%0A` +
                    `*Género:* ${genre}%0A` +
                    `*Instagram:* ${ig}%0A` +
                    `*Inversión:* $300 USD%0A%0A` +
                    `Quiero mi primer beat y la verificación de mis cuentas.`;

    window.open(`https://wa.me/584244737109?text=${message}`, '_blank');
    setIsModalOpen(false);
  };

  return (
    <div className="min-h-screen font-sans selection:bg-[#d4af37] selection:text-black">
      {/* Futuristic Speakers */}
      <Speaker side="left" isPlaying={!!playingId} />
      <Speaker side="right" isPlaying={!!playingId} />

      {/* Navigation */}
      <nav className="fixed top-0 w-full z-50 bg-[#0a0a0a]/80 backdrop-blur-lg border-b border-white/10 px-6 py-4">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <h1 className="text-2xl font-black tracking-tighter gold-gradient text-glow">IMER MUSIC</h1>
          <div className="hidden md:flex items-center space-x-8 text-xs uppercase tracking-widest font-semibold">
            <a href="#beats" className="hover:text-[#d4af37] transition-colors">Beats</a>
            <a href="#servicios" className="hover:text-[#d4af37] transition-colors">Servicios</a>
            <a href="#sello" className="hover:text-[#d4af37] transition-colors">Sello Disquero</a>
            <a href="#descarga" className="text-[#d4af37] border border-[#d4af37]/50 px-4 py-2 rounded-full hover:bg-[#d4af37] hover:text-black transition-all">
              Canjear Código
            </a>
          </div>
          <button className="md:hidden text-white">
            <ChevronRight className="rotate-90" />
          </button>
        </div>
      </nav>

      {/* Hero Section */}
      <header className="relative min-h-screen flex items-center justify-center pt-20 pb-20 px-6 text-center overflow-hidden">
        {/* Futuristic Studio Background */}
        <div className="absolute inset-0 -z-10">
          <img 
            src="https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?auto=format&fit=crop&q=80&w=2000" 
            alt="Futuristic Music Studio" 
            className="w-full h-full object-cover opacity-30 scale-110 animate-pulse-slow"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-linear-to-b from-[#0a0a0a]/80 via-[#0a0a0a]/40 to-[#0a0a0a]" />
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(212,175,55,0.15),transparent_70%)]" />
        </div>

        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1, ease: "easeOut" }}
          className="relative z-10"
        >
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2, duration: 0.8 }}
          >
            <h2 className="text-7xl md:text-9xl font-black mb-6 tracking-tighter text-glow-white">
              IMER <span className="gold-gradient text-glow">MUSIC</span>
            </h2>
          </motion.div>
          
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4, duration: 0.8 }}
            className="text-xl md:text-2xl text-gray-300 max-w-3xl mx-auto mb-12 leading-relaxed font-light tracking-wide"
          >
            Productor, Compositor y CEO de <span className="text-[#d4af37] font-bold">Imer Music</span>. 
            <br className="hidden md:block" />
            Fusionando el arte sonoro con la tecnología del futuro.
          </motion.p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <a href="#beats" className="btn-gold px-10 py-4 rounded-full text-lg shadow-xl">
              Explorar Beats
            </a>
            <a 
              href="https://wa.me/584244737109" 
              target="_blank"
              rel="noopener noreferrer"
              className="group border border-white/20 px-10 py-4 rounded-full hover:bg-white hover:text-black transition-all flex items-center justify-center gap-2"
            >
              Contacto Directo
              <ExternalLink size={18} className="group-hover:translate-x-1 transition-transform" />
            </a>
          </div>
        </motion.div>
      </header>

      {/* Beats Store */}
      <section id="beats" className="max-w-7xl mx-auto py-32 px-6">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-8 mb-16">
          <div className="flex items-center gap-4">
            <div className="h-10 w-1 bg-[#d4af37] shadow-[0_0_15px_#d4af37]" />
            <h3 className="text-4xl font-black tracking-tight uppercase text-glow-white">Catálogo Futurista</h3>
          </div>
          
          <div className="flex flex-col md:flex-row gap-4 w-full md:w-auto">
            <div className="relative group">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500 group-focus-within:text-[#d4af37] transition-colors" size={18} />
              <input 
                type="text" 
                placeholder="Buscar por género o título..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full md:w-80 bg-black/50 border border-white/10 rounded-2xl pl-12 pr-4 py-3 outline-none focus:border-[#d4af37] focus:shadow-[0_0_20px_rgba(212,175,55,0.2)] transition-all"
              />
            </div>
            <div className="flex gap-2 overflow-x-auto pb-2 md:pb-0 scrollbar-hide">
              {GENRES.map(genre => (
                <button
                  key={genre}
                  onClick={() => setSelectedGenre(genre)}
                  className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all whitespace-nowrap ${
                    selectedGenre === genre 
                    ? 'bg-[#d4af37] text-black shadow-[0_0_15px_rgba(212,175,55,0.5)]' 
                    : 'bg-white/5 text-gray-400 hover:bg-white/10'
                  }`}
                >
                  {genre}
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
          <AnimatePresence mode="popLayout">
            {filteredBeats.map((beat) => (
              <motion.div 
                key={beat.id}
                layout
                initial={{ opacity: 0, scale: 0.9, rotateY: 20 }}
                animate={{ opacity: 1, scale: 1, rotateY: 0 }}
                exit={{ opacity: 0, scale: 0.9 }}
                whileHover={{ 
                  scale: 1.02, 
                  rotateY: -5,
                  rotateX: 5,
                  z: 50,
                  boxShadow: "0 25px 50px -12px rgba(212, 175, 55, 0.2)"
                }}
                transition={{ type: "spring", stiffness: 300, damping: 20 }}
                className={`card-glass p-8 rounded-[2.5rem] relative overflow-hidden group perspective-1000 ${beat.sold ? 'opacity-50 grayscale' : ''}`}
                style={{ transformStyle: 'preserve-3d' }}
              >
                <div className="absolute top-0 right-0 w-32 h-32 bg-linear-to-br from-[#d4af37]/10 to-transparent -mr-16 -mt-16 rounded-full blur-3xl group-hover:bg-[#d4af37]/20 transition-all" />
                
                <div className="flex justify-between items-start mb-8">
                  <span className="bg-[#d4af37]/10 text-[#d4af37] text-[10px] font-black px-4 py-1.5 rounded-full tracking-[0.2em] uppercase border border-[#d4af37]/20">
                    {beat.genre}
                  </span>
                  {beat.sold ? (
                    <span className="text-red-500 text-[10px] font-black uppercase tracking-widest flex items-center gap-1">
                      <Lock size={12} /> Vendido
                    </span>
                  ) : (
                    <span className="text-emerald-400 text-[10px] font-black uppercase tracking-widest flex items-center gap-1 shadow-[0_0_10px_rgba(52,211,153,0.3)]">
                      <Check size={12} /> Disponible
                    </span>
                  )}
                </div>

                <div className="mb-8">
                  <h4 className="text-3xl font-black mb-2 tracking-tight group-hover:text-[#d4af37] transition-colors">{beat.title}</h4>
                  <p className="text-gray-500 text-xs font-mono tracking-widest">
                    {beat.duration} MIN | {beat.bpm} BPM | 48KHZ 24BIT
                  </p>
                </div>

                <div className="relative mb-10 group/player">
                  <div className="absolute inset-0 bg-[#d4af37]/5 rounded-2xl blur-md group-hover/player:bg-[#d4af37]/10 transition-all" />
                  <div className="relative flex items-center gap-4 p-4 bg-black/40 rounded-2xl border border-white/5">
                    <button 
                      onClick={() => togglePlay(beat)}
                      className="w-12 h-12 rounded-full bg-[#d4af37] text-black flex items-center justify-center shadow-[0_0_20px_rgba(212,175,55,0.4)] hover:scale-110 active:scale-90 transition-all"
                    >
                      {playingId === beat.id ? <Pause size={20} fill="currentColor" /> : <Play size={20} fill="currentColor" className="ml-1" />}
                    </button>
                    <div className="flex-1 h-1 bg-white/10 rounded-full overflow-hidden">
                      <motion.div 
                        animate={{ width: playingId === beat.id ? '100%' : '0%' }}
                        transition={{ duration: playingId === beat.id ? 180 : 0, ease: "linear" }}
                        className="h-full bg-linear-to-r from-[#d4af37] to-[#f2d472]" 
                      />
                    </div>
                  </div>
                </div>

                <div className="flex justify-between items-center pt-6 border-t border-white/5">
                  <div className="flex flex-col">
                    <span className="text-[10px] text-gray-500 uppercase font-black tracking-widest mb-1">Inversión</span>
                    <span className="text-3xl font-black text-[#d4af37] tracking-tighter drop-shadow-[0_0_10px_rgba(212,175,55,0.3)]">
                      ${beat.price.toFixed(2)}
                    </span>
                  </div>
                  {!beat.sold ? (
                    <a 
                      href={`https://wa.me/584244737109?text=Hola%20Imer,%20quiero%20comprar%20el%20beat%20${encodeURIComponent(beat.title)}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="btn-gold px-8 py-4 rounded-2xl text-xs uppercase tracking-[0.2em] shadow-[0_10px_20px_rgba(212,175,55,0.2)]"
                    >
                      Adquirir
                    </a>
                  ) : (
                    <button disabled className="bg-zinc-800/50 text-gray-600 px-8 py-4 rounded-2xl text-xs uppercase tracking-[0.2em] cursor-not-allowed">
                      Agotado
                    </button>
                  )}
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        {/* Admin Access */}
        <div className="mt-20 flex justify-center">
          <button 
            onClick={() => setIsAdminOpen(!isAdminOpen)}
            className="flex items-center gap-2 text-gray-600 hover:text-[#d4af37] transition-all text-[10px] font-black uppercase tracking-[0.3em]"
          >
            <Lock size={12} /> {isAdminOpen ? 'Cerrar Panel Control' : 'Acceso Administrador'}
          </button>
        </div>

        <AnimatePresence>
          {isAdminOpen && (
            <motion.div 
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="overflow-hidden"
            >
              <section id="admin-panel" className="max-w-4xl mx-auto my-12 p-8 card-glass rounded-3xl border-2 border-[#d4af37]">
                <h3 className="text-2xl font-bold mb-6 text-[#d4af37] italic uppercase tracking-tight">Panel de Carga Imer Music</h3>
                <form onSubmit={handleAddBeat} className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <input 
                    name="title" 
                    type="text" 
                    required 
                    placeholder="Nombre de la Pista" 
                    className="bg-black border border-white/20 p-4 rounded-xl outline-none focus:border-[#d4af37]" 
                  />
                  <select 
                    name="genre" 
                    className="bg-black border border-white/20 p-4 rounded-xl text-gray-400 outline-none focus:border-[#d4af37] appearance-none"
                  >
                    {GENRES.filter(g => g !== 'Todos').map(g => <option key={g} value={g}>{g}</option>)}
                  </select>
                  <input 
                    name="price" 
                    type="number" 
                    step="0.01" 
                    required 
                    placeholder="Precio ($ USD)" 
                    className="bg-black border border-white/20 p-4 rounded-xl outline-none focus:border-[#d4af37]" 
                  />
                  <div className="grid grid-cols-2 gap-4">
                    <input 
                      name="duration" 
                      required 
                      placeholder="Duración (Ej: 2:45)" 
                      className="bg-black border border-white/20 p-4 rounded-xl outline-none focus:border-[#d4af37]" 
                    />
                    <input 
                      name="bpm" 
                      type="number" 
                      required 
                      placeholder="BPM" 
                      className="bg-black border border-white/20 p-4 rounded-xl outline-none focus:border-[#d4af37]" 
                    />
                  </div>
                  
                  <div className="col-span-2">
                    <label className="block text-xs text-[#d4af37] mb-2 uppercase font-bold">Seleccionar Archivo Audio (WAV, MP3, FLAC)</label>
                    <input 
                      name="audio" 
                      type="file" 
                      accept=".wav,.mp3,.m4a,.ogg,.flac" 
                      required 
                      className="w-full bg-[#d4af37]/5 border border-dashed border-[#d4af37]/50 p-6 rounded-xl text-sm file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-[#d4af37] file:text-black"
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file && file.size > 100 * 1024 * 1024) {
                          alert("¡Error 413! El archivo es demasiado grande (Límite: 100MB).\n\nSi tu archivo es un WAV extremadamente pesado, por favor conviértelo a FLAC (misma calidad, mucho menos peso) o MP3 de alta calidad.");
                          e.target.value = ''; // Clear the input
                        }
                      }}
                    />
                  </div>
                  
                  <button 
                    type="submit" 
                    disabled={isUploading}
                    className={`btn-gold col-span-2 py-5 rounded-2xl text-xl font-black uppercase tracking-widest shadow-2xl ${isUploading ? 'opacity-50 cursor-not-allowed' : ''}`}
                  >
                    {isUploading ? 'Publicando...' : 'Publicar en Catálogo Profesional'}
                  </button>
                </form>

                {/* List of current beats with codes for admin */}
                <div className="mt-12 space-y-4">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-[#d4af37]/20 pb-2 gap-4">
                    <h4 className="text-sm font-black uppercase tracking-widest text-[#d4af37]">Gestión de Códigos</h4>
                    <div className="flex items-center gap-2 bg-black/50 border border-white/10 rounded-xl px-3 py-1.5">
                      <Search size={12} className="text-gray-500" />
                      <input 
                        type="text" 
                        placeholder="Filtrar códigos..." 
                        className="bg-transparent border-none outline-none text-[10px] w-32"
                        onChange={(e) => {
                          const val = e.target.value.toLowerCase();
                          const items = document.querySelectorAll('.admin-code-item');
                          items.forEach((item: any) => {
                            const text = item.innerText.toLowerCase();
                            item.style.display = text.includes(val) ? 'flex' : 'none';
                          });
                        }}
                      />
                    </div>
                  </div>
                  <p className="text-[10px] text-gray-400 italic">Aquí tienes todos los códigos. Si un cliente te pide una pista, busca el código aquí y envíaselo por WhatsApp.</p>
                  <div className="grid grid-cols-1 gap-3 max-h-96 overflow-y-auto pr-2 custom-scrollbar">
                    {beats.map(beat => {
                      const code = `${beat.title.toUpperCase().replace(/\s+/g, '-')}-${beat.id.substring(0, 4).toUpperCase()}`;
                      return (
                        <div key={beat.id} className="admin-code-item flex flex-col sm:flex-row justify-between items-start sm:items-center bg-black/40 p-4 rounded-2xl border border-white/5 gap-3 hover:border-[#d4af37]/30 transition-all group">
                          <div className="flex flex-col">
                            <span className="font-bold text-xs group-hover:text-[#d4af37] transition-colors">{beat.title}</span>
                            <div className="flex items-center gap-2 mt-1">
                              <code className="bg-black/50 text-[#d4af37] text-[10px] font-mono px-2 py-0.5 rounded border border-[#d4af37]/10">{code}</code>
                              <span className="text-[8px] text-gray-600 uppercase">{beat.genre}</span>
                            </div>
                          </div>
                          <div className="flex items-center gap-2 w-full sm:w-auto">
                            <button 
                              onClick={() => {
                                const info = `Pista: ${beat.title}\nCódigo: ${code}`;
                                navigator.clipboard.writeText(info);
                                alert("Info copiada: " + beat.title);
                              }}
                              className="flex-1 sm:flex-none bg-white/5 hover:bg-white/10 text-[9px] px-4 py-2 rounded-xl transition-colors uppercase font-black tracking-tighter"
                            >
                              Copiar Info
                            </button>
                            <button 
                              onClick={() => {
                                const message = `🎹 *CÓDIGO DE DESCARGA - IMER MUSIC* 🎹%0A%0A` +
                                                `*Pista:* ${beat.title}%0A` +
                                                `*Código:* ${code}%0A%0A` +
                                                `Entrega este código al cliente tras confirmar el pago.`;
                                window.open(`https://wa.me/584244737109?text=${message}`, '_blank');
                              }}
                              className="flex-1 sm:flex-none bg-[#25D366] hover:bg-[#128C7E] text-white text-[9px] px-4 py-2 rounded-xl transition-colors uppercase font-black tracking-tighter shadow-[0_0_15px_rgba(37,211,102,0.2)]"
                            >
                              WhatsApp
                            </button>
                          </div>
                        </div>
                      );
                    })}
                    {beats.length === 0 && <p className="text-gray-600 italic text-center py-8">No hay pistas en el catálogo aún.</p>}
                  </div>
                </div>
              </section>
            </motion.div>
          )}
        </AnimatePresence>
      </section>

      {/* Services Section */}
      <section id="servicios" className="bg-zinc-900/50 py-32 px-6 border-y border-white/5">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-20">
            <h2 className="text-5xl font-black mb-6 gold-gradient tracking-tight text-glow">IMPULSO PROFESIONAL COMPLETO</h2>
            <p className="text-gray-400 max-w-2xl mx-auto text-lg">
              No solo hacemos música, construimos tu carrera visual y digital con estándares internacionales.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="card-glass p-10 rounded-[2.5rem] text-center group">
              <div className="w-20 h-20 bg-[#d4af37]/10 rounded-3xl flex items-center justify-center mx-auto mb-8 group-hover:scale-110 transition-transform">
                <Cpu className="text-3xl text-[#d4af37]" />
              </div>
              <h4 className="text-2xl font-bold mb-4">Video Clips con IA</h4>
              <p className="text-gray-400 text-sm mb-8 leading-relaxed">
                Creamos visuales cinematográficos usando inteligencia artificial de última generación (Veo & Sora) para tus canciones.
              </p>
              <span className="text-[10px] font-black text-[#d4af37] tracking-[0.2em] uppercase italic bg-[#d4af37]/5 px-4 py-2 rounded-full">
                Tecnología Next-Gen
              </span>
            </div>

            <div className="card-glass p-10 rounded-[2.5rem] text-center group border-[#d4af37]/20">
              <div className="w-20 h-20 bg-[#d4af37]/10 rounded-3xl flex items-center justify-center mx-auto mb-8 group-hover:scale-110 transition-transform">
                <Globe className="text-3xl text-[#d4af37]" />
              </div>
              <h4 className="text-2xl font-bold mb-4">Distribución Global</h4>
              <p className="text-gray-400 text-sm mb-8 leading-relaxed">
                Llevamos tu música a más de 150 plataformas (Spotify, Apple, Deezer) con verificación oficial de artista.
              </p>
              <span className="text-[10px] font-black text-[#d4af37] tracking-[0.2em] uppercase italic bg-[#d4af37]/5 px-4 py-2 rounded-full">
                +150 Plataformas
              </span>
            </div>

            <div className="card-glass p-10 rounded-[2.5rem] text-center group">
              <div className="w-20 h-20 bg-[#d4af37]/10 rounded-3xl flex items-center justify-center mx-auto mb-8 group-hover:scale-110 transition-transform">
                <Mic className="text-3xl text-[#d4af37]" />
              </div>
              <h4 className="text-2xl font-bold mb-4">Vocal Coach</h4>
              <p className="text-gray-400 text-sm mb-8 leading-relaxed">
                Entrenamiento vocal personalizado para que tu interpretación en el estudio sea de nivel mundial y transmita emoción pura.
              </p>
              <span className="text-[10px] font-black text-[#d4af37] tracking-[0.2em] uppercase italic bg-[#d4af37]/5 px-4 py-2 rounded-full">
                Asesoría Directa
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* Label Membership */}
      <section id="sello" className="py-32 px-6">
        <div className="max-w-5xl mx-auto text-center">
          <h3 className="text-5xl md:text-6xl font-black mb-8 tracking-tight text-glow-white">
            Únete a <span className="gold-gradient text-glow">Imer Music Label</span>
          </h3>
          <p className="text-xl text-gray-400 mb-16 max-w-2xl mx-auto">
            Forma parte de nuestro sello por una inversión única y lanza tu carrera al estrellato con respaldo profesional.
          </p>
          
          <div className="bg-zinc-900 p-12 rounded-[3rem] border-2 border-[#d4af37]/30 inline-block text-left max-w-md w-full shadow-2xl relative">
            <div className="absolute -top-6 left-1/2 -translate-x-1/2 bg-[#d4af37] text-black text-[10px] font-black px-6 py-2 rounded-full tracking-widest uppercase">
              Suscripción Artista
            </div>
            <h4 className="text-7xl font-black text-center mb-8 tracking-tighter">
              $300 <span className="text-xl font-normal text-gray-500 tracking-normal">USD</span>
            </h4>
            <ul className="space-y-4 mb-12 text-sm">
              <li className="flex items-center gap-3">
                <div className="bg-[#d4af37]/20 p-1 rounded-full"><Check size={14} className="text-[#d4af37]" /></div>
                Creación de tu primer Beat personalizado
              </li>
              <li className="flex items-center gap-3">
                <div className="bg-[#d4af37]/20 p-1 rounded-full"><Check size={14} className="text-[#d4af37]" /></div>
                Lanzamiento a +150 plataformas
              </li>
              <li className="flex items-center gap-3">
                <div className="bg-[#d4af37]/20 p-1 rounded-full"><Check size={14} className="text-[#d4af37]" /></div>
                Verificación Spotify/TikTok/YouTube
              </li>
              <li className="flex items-center gap-3">
                <div className="bg-[#d4af37]/20 p-1 rounded-full"><Check size={14} className="text-[#d4af37]" /></div>
                Asesoría Vocal Coach profesional
              </li>
            </ul>
            <button 
              onClick={() => setIsModalOpen(true)}
              className="btn-gold w-full py-5 rounded-2xl text-lg uppercase tracking-widest shadow-lg active:scale-95 transition-transform"
            >
              Solicitar Ingreso
            </button>
          </div>
        </div>
      </section>

      {/* Download Section */}
      <section id="descarga" className="py-32 px-6 max-w-2xl mx-auto text-center">
        <div className="card-glass p-12 rounded-[3rem] border-[#d4af37]/10">
          <Download className="mx-auto mb-6 text-[#d4af37]" size={48} />
          <h3 className="text-3xl font-bold mb-4">¿Ya compraste tu pista?</h3>
          <p className="text-gray-400 mb-10">
            Ingresa tu código de descarga temporal enviado por WhatsApp para obtener tu archivo WAV de alta calidad.
          </p>
          <div className="flex flex-col sm:flex-row gap-3">
            <input 
              type="text" 
              value={downloadCode}
              onChange={(e) => setDownloadCode(e.target.value)}
              placeholder="Ej: IMER-9922-X" 
              className="bg-white/5 border border-white/10 px-6 py-4 rounded-2xl flex-1 outline-none focus:border-[#d4af37] transition-all font-mono uppercase"
            />
            <button 
              onClick={handleDownload}
              className="btn-gold px-8 py-4 rounded-2xl flex items-center justify-center gap-2"
            >
              Descargar <Download size={18} />
            </button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-20 border-t border-white/10 text-center px-6">
        <div className="flex justify-center space-x-8 mb-10">
          <a 
            href="https://linktr.ee/Imer7?utm_source=linktree_profile_share&ltsid=9ee680dd-ea2a-4877-98ab-81da6d1dfeda" 
            target="_blank" 
            rel="noopener noreferrer" 
            className="text-gray-400 hover:text-[#d4af37] transition-colors flex items-center gap-2"
          >
            <ExternalLink size={24} />
            <span className="font-bold uppercase tracking-widest text-sm">Mis Redes Sociales (Linktree)</span>
          </a>
        </div>
        <div className="flex justify-center space-x-8 mb-10">
          <a href="https://linktr.ee/Imer7" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-red-600 transition-colors"><Youtube size={28} /></a>
          <a href="https://linktr.ee/Imer7" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-pink-500 transition-colors"><Instagram size={28} /></a>
          <a href="https://linktr.ee/Imer7" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-blue-400 transition-colors"><Twitter size={28} /></a>
          <a href="https://linktr.ee/Imer7" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-cyan-400 transition-colors"><Music size={28} /></a>
        </div>
        <p className="text-gray-500 text-sm tracking-widest uppercase font-semibold">
          © 2026 Imer Music. All Rights Reserved.
        </p>
        <p className="text-gray-600 text-[10px] mt-2 uppercase tracking-[0.3em]">
          Powered by AI Elite Technology
        </p>
      </footer>

      {/* Chatbot */}
      <div className="fixed bottom-8 right-8 z-[100]">
        <button 
          onClick={() => setIsChatOpen(!isChatOpen)}
          className="btn-gold w-16 h-16 rounded-full shadow-2xl flex items-center justify-center text-2xl relative group"
        >
          <AnimatePresence mode="wait">
            {isChatOpen ? (
              <motion.div key="close" initial={{ rotate: -90, opacity: 0 }} animate={{ rotate: 0, opacity: 1 }} exit={{ rotate: 90, opacity: 0 }}>
                <X size={28} />
              </motion.div>
            ) : (
              <motion.div key="chat" initial={{ rotate: 90, opacity: 0 }} animate={{ rotate: 0, opacity: 1 }} exit={{ rotate: -90, opacity: 0 }}>
                <MessageSquare size={28} />
              </motion.div>
            )}
          </AnimatePresence>
          {!isChatOpen && (
            <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full border-2 border-black animate-pulse" />
          )}
        </button>
        
        <AnimatePresence>
          {isChatOpen && (
            <motion.div 
              initial={{ opacity: 0, y: 20, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 20, scale: 0.95 }}
              className="absolute bottom-20 right-0 w-80 md:w-96 card-glass rounded-[2rem] overflow-hidden flex flex-col shadow-2xl border-[#d4af37]/30"
            >
              <div className="bg-zinc-800 p-6 border-b border-white/5">
                <h5 className="font-black text-[#d4af37] uppercase tracking-widest">Comunidad Imer Music</h5>
                <p className="text-[10px] text-gray-400 uppercase tracking-[0.2em] mt-1">Asistente Virtual AI</p>
              </div>
              <div 
                ref={chatBodyRef}
                className="p-6 h-80 overflow-y-auto text-sm space-y-4 bg-black/80 scrollbar-hide"
              >
                {chatMessages.map((msg, i) => (
                  <motion.div 
                    initial={{ opacity: 0, x: msg.isUser ? 10 : -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    key={i} 
                    className={`${msg.isUser ? 'bg-[#d4af37]/20 ml-12 border border-[#d4af37]/20' : 'bg-zinc-800/80 mr-12'} p-4 rounded-2xl leading-relaxed`}
                  >
                    {msg.text}
                  </motion.div>
                ))}
              </div>
              <div className="p-4 bg-zinc-900/50 flex gap-2">
                <input 
                  type="text" 
                  value={chatInput}
                  onChange={(e) => setChatInput(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                  placeholder="Escribe algo..." 
                  className="bg-black border border-white/10 rounded-xl px-4 py-3 w-full text-xs focus:border-[#d4af37] outline-none transition-all"
                />
                <button 
                  onClick={handleSendMessage}
                  className="text-[#d4af37] p-3 hover:bg-[#d4af37]/10 rounded-xl transition-colors"
                >
                  <Send size={20} />
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Membership Modal */}
      <AnimatePresence>
        {isModalOpen && (
          <div className="fixed inset-0 z-[200] flex items-center justify-center p-6">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsModalOpen(false)}
              className="absolute inset-0 bg-black/90 backdrop-blur-md" 
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="card-glass max-w-lg w-full p-10 rounded-[3rem] border-2 border-[#d4af37]/50 relative z-10"
            >
              <button 
                onClick={() => setIsModalOpen(false)}
                className="absolute top-6 right-6 text-gray-500 hover:text-white transition-colors"
              >
                <X size={24} />
              </button>
              
              <div className="text-center mb-10">
                <h3 className="text-3xl font-black gold-gradient uppercase tracking-tight">Solicitud Imer Music Label</h3>
                <p className="text-gray-400 text-sm mt-2 uppercase tracking-widest">Membresía Elite Artista</p>
              </div>

              <form onSubmit={handleMembershipSubmit} className="space-y-6">
                <div>
                  <label className="text-[10px] uppercase text-[#d4af37] font-black tracking-widest ml-1 mb-2 block">Nombre Artístico</label>
                  <input 
                    name="art-name"
                    type="text" 
                    required 
                    placeholder="Ej: Young Imer" 
                    className="w-full bg-white/5 border border-white/10 rounded-2xl px-5 py-4 outline-none focus:border-[#d4af37] transition-all"
                  />
                </div>
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  <div>
                    <label className="text-[10px] uppercase text-[#d4af37] font-black tracking-widest ml-1 mb-2 block">Género Principal</label>
                    <select 
                      name="art-genre"
                      className="w-full bg-zinc-900 border border-white/10 rounded-2xl px-5 py-4 outline-none focus:border-[#d4af37] appearance-none"
                    >
                      <option>Rap / Hip Hop</option>
                      <option>Trap</option>
                      <option>Reggaetón</option>
                      <option>Pop / R&B</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-[10px] uppercase text-[#d4af37] font-black tracking-widest ml-1 mb-2 block">Instagram (@)</label>
                    <input 
                      name="art-ig"
                      type="text" 
                      required
                      placeholder="@usuario" 
                      className="w-full bg-white/5 border border-white/10 rounded-2xl px-5 py-4 outline-none focus:border-[#d4af37]"
                    />
                  </div>
                </div>

                <div className="bg-[#d4af37]/10 p-6 rounded-2xl border border-[#d4af37]/20">
                  <p className="text-xs text-yellow-200/80 leading-relaxed flex gap-3">
                    <Info size={16} className="shrink-0 mt-0.5" />
                    Al enviar, se generará una orden de <b>$300.00 USD</b> y serás redirigido a la oficina privada de Imer para concretar el pago y la verificación.
                  </p>
                </div>

                <button 
                  type="submit" 
                  className="btn-gold w-full py-5 rounded-2xl font-black text-lg shadow-[0_0_30px_rgba(212,175,55,0.3)] uppercase tracking-widest active:scale-95 transition-transform"
                >
                  Enviar y Pagar $300
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
